#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <ESP8266HTTPClient.h>
#include <SPI.h>
#include <MFRC522.h>
#include <Adafruit_Fingerprint.h>
#include <SoftwareSerial.h>
#include <ArduinoJson.h>

// RFID pin configuration
#define RST_PIN D3  // RST to D3 (GPIO0)
#define SS_PIN D4   // SDA to D4 (GPIO2)
MFRC522 rfid(SS_PIN, RST_PIN);

// Fingerprint sensor configuration
#define FINGERPRINT_RX D1  // Connect to TX on fingerprint sensor
#define FINGERPRINT_TX D2  // Connect to RX on fingerprint sensor
SoftwareSerial fingerprintSerial(FINGERPRINT_RX, FINGERPRINT_TX);
Adafruit_Fingerprint finger = Adafruit_Fingerprint(&fingerprintSerial);

// WiFi credentials
const char* ssid = "Galaxy S9+3b92";
const char* password = "00000000";

// Web server
ESP8266WebServer server(80);

// Server URL and API key
const char* serverURL = "http://82.112.241.179:8000/attendances";
const char* apiKey = "b3f65ecc04820ba6cdd0a3d0ac9a4f57162c6c9a06efac5ceca41e5f6e3ae956";

// Operation mode
bool fingerprintMode = true;
bool attendanceMode = false;
bool enrollmentInProgress = false;
int enrollmentID = -1;

// Attendance records buffer
struct AttendanceRecord {
  String timestamp;
  String rfidTag;
  int fingerprintID;
  String status;
};

AttendanceRecord recentRecords[10];
int recordIndex = 0;

void setup() {
  Serial.begin(9600);
  while (!Serial);
  delay(2000);
  
  // Initialize WiFi
  WiFi.begin(ssid, password);
  Serial.print("Connecting to WiFi...");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nConnected to WiFi");
  Serial.print("IP address: ");
  Serial.println(WiFi.localIP());
  Serial.print("MAC address: ");
  Serial.println(WiFi.macAddress());
  
  // Start RFID
  SPI.begin();
  rfid.PCD_Init();
  Serial.println("RFID reader initialized");
  
  // Start Fingerprint sensor
  fingerprintSerial.begin(57600);
  delay(500);
  finger.begin(57600);
  delay(1000);
  
  Serial.println("Checking fingerprint sensor...");
  for (int i = 0; i < 5; i++) {
    if (finger.verifyPassword()) {
      Serial.println("Fingerprint sensor connected!");
      break;
    } else {
      Serial.println("Fingerprint sensor not found! Retrying... " + String(i+1));
      delay(1000);
    }
  }
  
  if (!finger.verifyPassword()) {
    Serial.println("Continuing without fingerprint sensor. Switching to RFID-only mode.");
    fingerprintMode = false;
  } else {
    finger.getParameters();
    Serial.print("Status: 0x"); Serial.println(finger.status_reg, HEX);
    Serial.print("System ID: 0x"); Serial.println(finger.system_id, HEX);
    Serial.print("Capacity: "); Serial.println(finger.capacity);
    Serial.print("Security level: "); Serial.println(finger.security_level);
  }
  
  // Setup web server routes
  setupWebServer();
  
  // Enable CORS for all routes
  server.enableCORS(true);
  
  // Start web server
  server.begin();
  Serial.println("Web server started");
  
  Serial.println("\n=== FINGERPRINT & RFID ATTENDANCE SYSTEM ===");
  Serial.println("Web interface available at: http://" + WiFi.localIP().toString());
}

void setupWebServer() {
  // CORS preflight
  server.on("/", HTTP_OPTIONS, []() {
    server.sendHeader("Access-Control-Allow-Origin", "*");
    server.sendHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    server.sendHeader("Access-Control-Allow-Headers", "Content-Type");
    server.send(200);
  });
  
  // Status endpoint
  server.on("/status", HTTP_GET, []() {
    server.sendHeader("Access-Control-Allow-Origin", "*");
    DynamicJsonDocument doc(200);
    doc["status"] = "connected";
    doc["fingerprint_sensor"] = fingerprintMode;
    doc["attendance_mode"] = attendanceMode;
    doc["ip"] = WiFi.localIP().toString();
    
    String response;
    serializeJson(doc, response);
    server.send(200, "application/json", response);
  });
  
  // List fingerprints
  server.on("/fingerprints", HTTP_GET, []() {
    server.sendHeader("Access-Control-Allow-Origin", "*");
    handleListFingerprints();
  });
  
  // Enroll fingerprint
  server.on("/enroll", HTTP_POST, []() {
    server.sendHeader("Access-Control-Allow-Origin", "*");
    handleEnrollFingerprint();
  });
  
  // Delete fingerprint
  server.on("/delete", HTTP_POST, []() {
    server.sendHeader("Access-Control-Allow-Origin", "*");
    handleDeleteFingerprint();
  });
  
  // Toggle attendance mode
  server.on("/attendance", HTTP_POST, []() {
    server.sendHeader("Access-Control-Allow-Origin", "*");
    handleAttendanceMode();
  });
  
  // Get attendance records
  server.on("/attendance-records", HTTP_GET, []() {
    server.sendHeader("Access-Control-Allow-Origin", "*");
    handleGetAttendanceRecords();
  });
}

void loop() {
  server.handleClient();
  
  if (attendanceMode) {
    handleAttendanceScanning();
  }
  
  if (enrollmentInProgress) {
    handleEnrollmentProcess();
  }
  
  delay(100);
}

void handleListFingerprints() {
  if (!finger.verifyPassword()) {
    server.send(500, "application/json", "{\"error\":\"Fingerprint sensor not connected\"}");
    return;
  }
  
  DynamicJsonDocument doc(2048);
  JsonArray fingerprints = doc.createNestedArray("fingerprints");
  
  for (int id = 1; id <= 127; id++) {
    uint8_t result = finger.loadModel(id);
    if (result == FINGERPRINT_OK) {
      JsonObject fp = fingerprints.createNestedObject();
      fp["id"] = id;
      fp["status"] = "stored";
    }
  }
  
  String response;
  serializeJson(doc, response);
  server.send(200, "application/json", response);
}

void handleEnrollFingerprint() {
  if (!server.hasArg("plain")) {
    server.send(400, "application/json", "{\"error\":\"No data received\"}");
    return;
  }
  
  DynamicJsonDocument doc(200);
  deserializeJson(doc, server.arg("plain"));
  
  int id = doc["id"];
  
  if (id < 1 || id > 127) {
    server.send(400, "application/json", "{\"error\":\"Invalid ID. Must be between 1 and 127\"}");
    return;
  }
  
  // Check if ID already exists
  uint8_t result = finger.loadModel(id);
  if (result == FINGERPRINT_OK) {
    server.send(400, "application/json", "{\"error\":\"ID already in use\"}");
    return;
  }
  
  enrollmentInProgress = true;
  enrollmentID = id;
  
  Serial.println("Starting enrollment for ID: " + String(id));
  Serial.println("Please place finger on sensor...");
  
  server.send(200, "application/json", "{\"message\":\"Enrollment started. Please place finger on sensor.\"}");
}

void handleDeleteFingerprint() {
  if (!server.hasArg("plain")) {
    server.send(400, "application/json", "{\"error\":\"No data received\"}");
    return;
  }
  
  DynamicJsonDocument doc(200);
  deserializeJson(doc, server.arg("plain"));
  
  int id = doc["id"];
  
  if (!finger.verifyPassword()) {
    server.send(500, "application/json", "{\"error\":\"Fingerprint sensor not connected\"}");
    return;
  }
  
  uint8_t p = finger.loadModel(id);
  if (p != FINGERPRINT_OK) {
    server.send(404, "application/json", "{\"error\":\"Fingerprint not found\"}");
    return;
  }
  
  p = finger.deleteModel(id);
  if (p == FINGERPRINT_OK) {
    server.send(200, "application/json", "{\"message\":\"Fingerprint deleted successfully\"}");
  } else {
    server.send(500, "application/json", "{\"error\":\"Failed to delete fingerprint\"}");
  }
}

void handleAttendanceMode() {
  if (!server.hasArg("plain")) {
    server.send(400, "application/json", "{\"error\":\"No data received\"}");
    return;
  }
  
  DynamicJsonDocument doc(200);
  deserializeJson(doc, server.arg("plain"));
  
  bool mode = doc["mode"];
  attendanceMode = mode;
  
  if (attendanceMode) {
    Serial.println("Attendance mode activated via web interface");
  } else {
    Serial.println("Attendance mode deactivated via web interface");
  }
  
  server.send(200, "application/json", "{\"message\":\"Attendance mode " + String(attendanceMode ? "activated" : "deactivated") + "\"}");
}

void handleGetAttendanceRecords() {
  DynamicJsonDocument doc(2048);
  JsonArray records = doc.createNestedArray("records");
  
  for (int i = 0; i < 10; i++) {
    int idx = (recordIndex - 1 - i + 10) % 10;
    if (recentRecords[idx].timestamp.length() > 0) {
      JsonObject record = records.createNestedObject();
      record["timestamp"] = recentRecords[idx].timestamp;
      record["rfidTag"] = recentRecords[idx].rfidTag;
      if (recentRecords[idx].fingerprintID >= 0) {
        record["fingerprintID"] = recentRecords[idx].fingerprintID;
      }
      record["status"] = recentRecords[idx].status;
    }
  }
  
  String response;
  serializeJson(doc, response);
  server.send(200, "application/json", response);
}

void handleEnrollmentProcess() {
  // This is a simplified version - you might want to implement a more sophisticated state machine
  static int enrollmentStep = 0;
  static unsigned long lastStepTime = 0;
  
  if (millis() - lastStepTime > 1000) { // Check every second
    uint8_t result = enrollFingerprint(enrollmentID);
    if (result == FINGERPRINT_OK) {
      Serial.println("Enrollment completed successfully!");
      enrollmentInProgress = false;
      enrollmentStep = 0;
    } else if (result == 255) {
      Serial.println("Enrollment failed or cancelled");
      enrollmentInProgress = false;
      enrollmentStep = 0;
    }
    lastStepTime = millis();
  }
}

void handleAttendanceScanning() {
  String uid = "";
  
  if (rfid.PICC_IsNewCardPresent() && rfid.PICC_ReadCardSerial()) {
    // Read UID
    for (byte i = 0; i < rfid.uid.size; i++) {
      if (rfid.uid.uidByte[i] < 0x10) uid += "0";
      uid += String(rfid.uid.uidByte[i], HEX);
    }
    uid.toUpperCase();
    Serial.println("RFID Card detected - UID: " + uid);
    
    int fingerprintID = -1;
    String status = "success";
    
    // If fingerprint mode is on, wait for fingerprint scan
    if (fingerprintMode) {
      Serial.println("Please place finger on sensor...");
      
      unsigned long startTime = millis();
      boolean timeout = false;
      boolean fingerFound = false;
      
      while (!fingerFound && !timeout) {
        fingerprintID = getFingerprintID();
        if (fingerprintID >= 0) {
          fingerFound = true;
          Serial.println("Fingerprint matched! ID #" + String(fingerprintID));
        }
        
        if (millis() - startTime > 10000) {
          timeout = true;
          Serial.println("Fingerprint scan timeout");
          status = "timeout";
        }
        
        delay(100);
      }
    }
    
    // Store attendance record
    recentRecords[recordIndex].timestamp = String(millis());
    recentRecords[recordIndex].rfidTag = uid;
    recentRecords[recordIndex].fingerprintID = fingerprintID;
    recentRecords[recordIndex].status = status;
    recordIndex = (recordIndex + 1) % 10;
    
    // Send attendance data to external server
    if (WiFi.status() == WL_CONNECTED) {
      sendAttendanceData(uid, fingerprintID);
    } else {
      Serial.println("WiFi disconnected");
    }
    
    delay(1000);
    rfid.PICC_HaltA();
    Serial.println("Ready for next scan...");
  }
}

// Keep your existing fingerprint functions but modify enrollFingerprint to work with web interface
uint8_t enrollFingerprint(int id) {
  if (!finger.verifyPassword()) {
    return 255;
  }
  
  Serial.print("Enrolling ID #"); 
  Serial.println(id);
  
  int p = -1;
  
  // First image capture
  Serial.println("Place finger on sensor...");
  while (p != FINGERPRINT_OK) {
    p = finger.getImage();
    switch (p) {
      case FINGERPRINT_OK:
        Serial.println("Image taken");
        break;
      case FINGERPRINT_NOFINGER:
        delay(100);
        break;
      default:
        Serial.println("Error capturing fingerprint");
        return p;
    }
  }
  
  p = finger.image2Tz(1);
  if (p != FINGERPRINT_OK) {
    Serial.println("Error converting image.");
    return p;
  }
  
  // Check for duplicates
  Serial.println("Checking for duplicate fingerprints...");
  p = finger.fingerSearch(1);
  
  if (p == FINGERPRINT_OK) {
    Serial.print("This fingerprint already exists at ID #");
    Serial.print(finger.fingerID);
    Serial.println(" Cannot enroll duplicate fingerprint.");
    return 255;
  } else if (p == FINGERPRINT_NOTFOUND) {
    Serial.println("No duplicate found. Continuing enrollment...");
  } else {
    Serial.print("Error during fingerprint search: ");
    Serial.println(p);
    return p;
  }
  
  // Second image capture
  Serial.println("Remove finger...");
  delay(2000);
  while (finger.getImage() != FINGERPRINT_NOFINGER);
  
  Serial.println("Place same finger again...");
  p = -1;
  while (p != FINGERPRINT_OK) {
    p = finger.getImage();
    switch (p) {
      case FINGERPRINT_OK:
        Serial.println("Image taken");
        break;
      case FINGERPRINT_NOFINGER:
        delay(100);
        break;
      default:
        Serial.println("Error capturing fingerprint");
        return p;
    }
  }
  
  p = finger.image2Tz(2);
  if (p != FINGERPRINT_OK) {
    Serial.println("Error converting second image.");
    return p;
  }
  
  // Create and store model
  p = finger.createModel();
  if (p != FINGERPRINT_OK) {
    Serial.println("Fingerprints did not match.");
    return p;
  }
  
  p = finger.storeModel(id);
  if (p == FINGERPRINT_OK) {
    Serial.println("Successfully stored fingerprint!");
    return FINGERPRINT_OK;
  } else {
    Serial.println("Error storing fingerprint.");
    return p;
  }
}

int getFingerprintID() {
  int p = finger.getImage();
  
  if (p != FINGERPRINT_OK) {
    if (p != FINGERPRINT_NOFINGER) {
      Serial.print("Error getting image: ");
      switch (p) {
        case FINGERPRINT_PACKETRECIEVEERR: Serial.println("Communication error"); break;
        case FINGERPRINT_IMAGEFAIL: Serial.println("Imaging error"); break;
        default: Serial.println("Unknown error"); break;
      }
    }
    return -1;
  }
  
  p = finger.image2Tz();
  if (p != FINGERPRINT_OK) {
    Serial.print("Image conversion error: ");
    switch (p) {
      case FINGERPRINT_IMAGEMESS: Serial.println("Image too messy"); break;
      case FINGERPRINT_PACKETRECIEVEERR: Serial.println("Communication error"); break;
      case FINGERPRINT_FEATUREFAIL: Serial.println("Couldn't find features"); break;
      case FINGERPRINT_INVALIDIMAGE: Serial.println("Invalid image"); break;
      default: Serial.println("Unknown error"); break;
    }
    return -1;
  }
  
  p = finger.fingerFastSearch();
  if (p != FINGERPRINT_OK) {
    if (p != FINGERPRINT_NOTFOUND) {
      Serial.print("Search error: ");
      switch (p) {
        case FINGERPRINT_PACKETRECIEVEERR: Serial.println("Communication error"); break;
        default: Serial.println("Unknown error"); break;
      }
    }
    return -1;
  }
  
  return finger.fingerID;
}

void sendAttendanceData(String uid, int fingerprintID) {
  WiFiClient client;
  HTTPClient http;
  
  Serial.print("Connecting to: ");
  Serial.println(serverURL);
  
  http.begin(client, serverURL);
  http.addHeader("Content-Type", "application/json");
  http.addHeader("Authorization", apiKey);
  
  String payload;
  if (fingerprintID >= 0) {
    payload = "{\"rfidTag\":\"" + uid + "\",\"fingerprintID\":\"" + String(fingerprintID) + "\",\"apiKey\":\"" + String(apiKey) + "\"}";
  } else {
    payload = "{\"rfidTag\":\"" + uid + "\",\"apiKey\":\"" + String(apiKey) + "\"}";
  }
  
  Serial.print("Sending payload: ");
  Serial.println(payload);
  
  http.setTimeout(10000);
  int httpCode = http.POST(payload);
  
  if (httpCode > 0) {
    if (httpCode >= 200 && httpCode < 300) {
      Serial.println("✓ Access Registered");
    } else if (httpCode >= 400) {
      Serial.println("✗ Access Denied");
    } else {
      Serial.print("HTTP Response Code: ");
      Serial.println(httpCode);
    }
    
    String response = http.getString();
    Serial.println("Server response: " + response);
  } else {
    Serial.print("HTTP request failed, error: ");
    Serial.println(http.errorToString(httpCode).c_str());
  }
  
  http.end();
}
