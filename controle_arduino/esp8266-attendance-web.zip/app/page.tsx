"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Trash2, Plus, Scan, Wifi, WifiOff, Fingerprint, CreditCard } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface FingerprintData {
  id: number
  status: string
}

interface AttendanceRecord {
  timestamp: string
  rfidTag: string
  fingerprintID?: number
  status: string
}

export default function ESP8266AttendanceSystem() {
  const [esp8266IP, setEsp8266IP] = useState("192.168.1.100") // Default IP
  const [isConnected, setIsConnected] = useState(false)
  const [fingerprints, setFingerprints] = useState<FingerprintData[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [attendanceMode, setAttendanceMode] = useState(false)
  const [newFingerprintId, setNewFingerprintId] = useState("")
  const [isEnrollDialogOpen, setIsEnrollDialogOpen] = useState(false)
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([])
  const { toast } = useToast()

  // Test connection to ESP8266
  const testConnection = async () => {
    setIsLoading(true)
    try {
      const response = await fetch(`http://${esp8266IP}/status`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })

      if (response.ok) {
        setIsConnected(true)
        toast({
          title: "Connected",
          description: "Successfully connected to ESP8266",
        })
        await loadFingerprints()
      } else {
        throw new Error("Connection failed")
      }
    } catch (error) {
      setIsConnected(false)
      toast({
        title: "Connection Failed",
        description: "Could not connect to ESP8266. Check IP address and network.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Load all stored fingerprints
  const loadFingerprints = async () => {
    if (!isConnected) return

    setIsLoading(true)
    try {
      const response = await fetch(`http://${esp8266IP}/fingerprints`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      })

      if (response.ok) {
        const data = await response.json()
        setFingerprints(data.fingerprints || [])
        toast({
          title: "Fingerprints Loaded",
          description: `Found ${data.fingerprints?.length || 0} stored fingerprints`,
        })
      } else {
        throw new Error("Failed to load fingerprints")
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load fingerprints from ESP8266",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Enroll new fingerprint
  const enrollFingerprint = async () => {
    if (!newFingerprintId || !isConnected) return

    const id = Number.parseInt(newFingerprintId)
    if (id < 1 || id > 127) {
      toast({
        title: "Invalid ID",
        description: "Fingerprint ID must be between 1 and 127",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      const response = await fetch(`http://${esp8266IP}/enroll`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ id: id }),
      })

      if (response.ok) {
        const data = await response.json()
        toast({
          title: "Enrollment Started",
          description: `Please place finger on sensor for ID ${id}. Follow ESP8266 serial monitor for instructions.`,
        })
        setIsEnrollDialogOpen(false)
        setNewFingerprintId("")
        // Reload fingerprints after a delay to allow enrollment to complete
        setTimeout(() => loadFingerprints(), 10000)
      } else {
        const errorData = await response.json()
        throw new Error(errorData.message || "Enrollment failed")
      }
    } catch (error) {
      toast({
        title: "Enrollment Failed",
        description: error instanceof Error ? error.message : "Failed to start fingerprint enrollment",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Delete fingerprint
  const deleteFingerprint = async (id: number) => {
    if (!isConnected) return

    setIsLoading(true)
    try {
      const response = await fetch(`http://${esp8266IP}/delete`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ id: id }),
      })

      if (response.ok) {
        toast({
          title: "Fingerprint Deleted",
          description: `Successfully deleted fingerprint ID ${id}`,
        })
        await loadFingerprints()
      } else {
        const errorData = await response.json()
        throw new Error(errorData.message || "Deletion failed")
      }
    } catch (error) {
      toast({
        title: "Deletion Failed",
        description: error instanceof Error ? error.message : "Failed to delete fingerprint",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Toggle attendance mode
  const toggleAttendanceMode = async () => {
    if (!isConnected) return

    setIsLoading(true)
    try {
      const response = await fetch(`http://${esp8266IP}/attendance`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ mode: !attendanceMode }),
      })

      if (response.ok) {
        setAttendanceMode(!attendanceMode)
        toast({
          title: attendanceMode ? "Attendance Mode Stopped" : "Attendance Mode Started",
          description: attendanceMode ? "System returned to setup mode" : "Ready to scan RFID cards and fingerprints",
        })
      } else {
        throw new Error("Failed to toggle attendance mode")
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to toggle attendance mode",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  // Poll for attendance records when in attendance mode
  useEffect(() => {
    if (!attendanceMode || !isConnected) return

    const pollAttendance = async () => {
      try {
        const response = await fetch(`http://${esp8266IP}/attendance-records`)
        if (response.ok) {
          const data = await response.json()
          if (data.records && data.records.length > 0) {
            setAttendanceRecords((prev) => [...data.records, ...prev].slice(0, 50)) // Keep last 50 records
          }
        }
      } catch (error) {
        console.error("Failed to poll attendance records:", error)
      }
    }

    const interval = setInterval(pollAttendance, 2000) // Poll every 2 seconds
    return () => clearInterval(interval)
  }, [attendanceMode, isConnected, esp8266IP])

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold text-gray-900">ESP8266 Attendance System</h1>
          <p className="text-gray-600">Fingerprint & RFID Management Interface</p>
        </div>

        {/* Connection Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {isConnected ? <Wifi className="h-5 w-5 text-green-500" /> : <WifiOff className="h-5 w-5 text-red-500" />}
              ESP8266 Connection
            </CardTitle>
            <CardDescription>Configure and test connection to your ESP8266 device</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-4 items-end">
              <div className="flex-1">
                <Label htmlFor="esp8266-ip">ESP8266 IP Address</Label>
                <Input
                  id="esp8266-ip"
                  value={esp8266IP}
                  onChange={(e) => setEsp8266IP(e.target.value)}
                  placeholder="192.168.1.100"
                  disabled={isLoading}
                />
              </div>
              <Button onClick={testConnection} disabled={isLoading}>
                {isLoading ? "Testing..." : "Test Connection"}
              </Button>
            </div>

            {isConnected && (
              <Alert>
                <Wifi className="h-4 w-4" />
                <AlertDescription>Successfully connected to ESP8266 at {esp8266IP}</AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>

        {/* Control Panel */}
        {isConnected && (
          <div className="grid md:grid-cols-2 gap-6">
            {/* Fingerprint Management */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Fingerprint className="h-5 w-5" />
                  Fingerprint Management
                </CardTitle>
                <CardDescription>Manage stored fingerprints on the ESP8266 sensor</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-semibold">Stored Fingerprints ({fingerprints.length})</h3>
                  <div className="flex gap-2">
                    <Button onClick={loadFingerprints} variant="outline" size="sm" disabled={isLoading}>
                      Refresh
                    </Button>
                    <Dialog open={isEnrollDialogOpen} onOpenChange={setIsEnrollDialogOpen}>
                      <DialogTrigger asChild>
                        <Button size="sm" disabled={isLoading}>
                          <Plus className="h-4 w-4 mr-2" />
                          Add Fingerprint
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Enroll New Fingerprint</DialogTitle>
                          <DialogDescription>
                            Enter an ID (1-127) for the new fingerprint. Make sure the ID is not already in use.
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="fingerprint-id">Fingerprint ID</Label>
                            <Input
                              id="fingerprint-id"
                              type="number"
                              min="1"
                              max="127"
                              value={newFingerprintId}
                              onChange={(e) => setNewFingerprintId(e.target.value)}
                              placeholder="Enter ID (1-127)"
                            />
                          </div>
                        </div>
                        <DialogFooter>
                          <Button variant="outline" onClick={() => setIsEnrollDialogOpen(false)}>
                            Cancel
                          </Button>
                          <Button onClick={enrollFingerprint} disabled={!newFingerprintId || isLoading}>
                            Start Enrollment
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>

                {fingerprints.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>ID</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {fingerprints.map((fp) => (
                        <TableRow key={fp.id}>
                          <TableCell className="font-medium">#{fp.id}</TableCell>
                          <TableCell>
                            <Badge variant="secondary">{fp.status}</Badge>
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => deleteFingerprint(fp.id)}
                              disabled={isLoading}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    No fingerprints stored. Click "Add Fingerprint" to enroll a new one.
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Attendance Mode */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="h-5 w-5" />
                  Attendance Mode
                </CardTitle>
                <CardDescription>Start/stop attendance scanning mode</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center space-y-4">
                  <div className="p-6 border-2 border-dashed border-gray-300 rounded-lg">
                    <Scan className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                    <p className="text-lg font-semibold">
                      {attendanceMode ? "Attendance Mode Active" : "Attendance Mode Inactive"}
                    </p>
                    <p className="text-sm text-gray-600">
                      {attendanceMode
                        ? "System is ready to scan RFID cards and verify fingerprints"
                        : "Click the button below to start attendance scanning"}
                    </p>
                  </div>

                  <Button
                    onClick={toggleAttendanceMode}
                    disabled={isLoading}
                    variant={attendanceMode ? "destructive" : "default"}
                    size="lg"
                    className="w-full"
                  >
                    {attendanceMode ? "Stop Attendance Mode" : "Start Attendance Mode"}
                  </Button>
                </div>

                {/* Recent Attendance Records */}
                {attendanceRecords.length > 0 && (
                  <div className="space-y-2">
                    <h4 className="font-semibold">Recent Scans</h4>
                    <div className="max-h-40 overflow-y-auto space-y-1">
                      {attendanceRecords.slice(0, 5).map((record, index) => (
                        <div key={index} className="text-xs p-2 bg-gray-50 rounded">
                          <div className="flex justify-between">
                            <span>RFID: {record.rfidTag}</span>
                            <span className={record.status === "success" ? "text-green-600" : "text-red-600"}>
                              {record.status}
                            </span>
                          </div>
                          {record.fingerprintID && (
                            <div className="text-gray-600">Fingerprint: #{record.fingerprintID}</div>
                          )}
                          <div className="text-gray-500">{record.timestamp}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {/* Instructions */}
        <Card>
          <CardHeader>
            <CardTitle>Setup Instructions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <h4 className="font-semibold mb-2">ESP8266 Setup:</h4>
                <ol className="list-decimal list-inside space-y-1 text-sm">
                  <li>Upload the modified Arduino code to your ESP8266</li>
                  <li>Connect your RFID reader and fingerprint sensor</li>
                  <li>Note the IP address shown in the serial monitor</li>
                  <li>Enter the IP address above and test connection</li>
                </ol>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Usage:</h4>
                <ol className="list-decimal list-inside space-y-1 text-sm">
                  <li>Add fingerprints using the enrollment dialog</li>
                  <li>View and manage stored fingerprints in the table</li>
                  <li>Start attendance mode for scanning</li>
                  <li>Monitor real-time attendance records</li>
                </ol>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
